import { supabase } from "./supabase";
import type {
  Comment,
  Message,
  User, 
  Listing, 
  LoginCredentials, 
  RegisterData, 
  ApiResponse,
  Interest,
  HousingType,
  LifestyleTag,
  KazakhstanCity
} from '../types';
import { useAuthStore, useListingsStore, useInterestsStore, useCommentsStore, useMessagesStore } from '../store';

// Simulated delay for API calls
const delay = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

// Mock user database
const mockUsers: User[] = [
  {
    id: 'u1',
    name: 'Айгуль К.',
    email: 'aigul@example.com',
    city: 'Алматы',
    avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150',
    bio: 'Владелец квартиры, сдаю уже 3 года. Люблю порядок и уют.',
    createdAt: '2024-01-15',
  },
];

// Auth Service
export const authService = {
  async login(credentials: LoginCredentials): Promise<ApiResponse<User>> {
    if (!useAuthStore.getState().isDemoMode) {
      // Real Supabase Auth
      const { data: authData, error: authError } = await supabase.auth.signInWithPassword({
        email: credentials.email,
        password: credentials.password,
      });

      if (authError) return { success: false, error: authError.message };

      if (authData.user) {
        // Fetch user profile from public.users table
        const { data: userProfile, error: profileError } = await supabase
          .from('users')
          .select('*')
          .eq('id', authData.user.id)
          .single();

        if (profileError) return { success: false, error: profileError.message };
        return { success: true, data: userProfile };
      }
      return { success: false, error: 'Unknown error during login' };
    }

    await delay(800);
    
    // Mock authentication
    const user = mockUsers.find((u) => u.email === credentials.email);
    
    if (user && credentials.password === 'demo123') {
      return { success: true, data: user };
    }
    
    // For demo, create a user on login
    const demoUser: User = {
      id: `user-${Date.now()}`,
      name: 'Демо Пользователь',
      email: credentials.email,
      city: 'Алматы',
      createdAt: new Date().toISOString(),
    };
    
    return { success: true, data: demoUser };
  },

  async register(data: RegisterData): Promise<ApiResponse<User>> {
    if (!useAuthStore.getState().isDemoMode) {
      const { data: authData, error: authError } = await supabase.auth.signUp({
        email: data.email,
        password: data.password,
      });

      if (authError) return { success: false, error: authError.message };

      if (authData.user) {
        // Create user profile in public.users table
        const { data: userProfile, error: profileError } = await supabase
          .from('users')
          .insert({
            id: authData.user.id,
            name: data.name,
            email: data.email,
            city: data.city,
          })
          .select()
          .single();

        if (profileError) return { success: false, error: profileError.message };
        return { success: true, data: userProfile };
      }
      return { success: false, error: 'Unknown error during registration' };
    }

    await delay(800);
    
    // Mock registration
    const newUser: User = {
      id: `user-${Date.now()}`,
      name: data.name,
      email: data.email,
      city: data.city,
      createdAt: new Date().toISOString(),
    };
    
    return { success: true, data: newUser };
  },

  async logout(): Promise<ApiResponse<void>> {
    if (!useAuthStore.getState().isDemoMode) {
      await supabase.auth.signOut();
    }
    await delay(300);
    return { success: true };
  },

  async getCurrentUser(): Promise<ApiResponse<User | null>> {
    await delay(300);
    const { user } = useAuthStore.getState();
    return { success: true, data: user };
  },

  async getUserById(userId: string): Promise<ApiResponse<User | null>> {
    if (!useAuthStore.getState().isDemoMode) {
      const { data, error } = await supabase.from('users').select('*').eq('id', userId).single();
      if (error) return { success: false, error: error.message };
      return { success: true, data: data };
    }

    await delay(300);
    const user = mockUsers.find(u => u.id === userId);
    return { success: true, data: user || null };
  },

  async updateProfile(userId: string, data: Partial<User>): Promise<ApiResponse<User>> {
    if (!useAuthStore.getState().isDemoMode) {
      const { data: updatedUser, error } = await supabase
        .from('users')
        .update(data)
        .eq('id', userId)
        .select()
        .single();

      if (error) return { success: false, error: error.message };

      // Update local store as well
      const { user, login } = useAuthStore.getState();
      if (user && user.id === userId) {
        login({ ...user, ...updatedUser });
      }

      return { success: true, data: updatedUser };
    }

    await delay(500);
    const { user, login } = useAuthStore.getState();
    if (!user || user.id !== userId) return { success: false, error: 'User not found or unauthorized' };

    const updatedUser = { ...user, ...data };
    login(updatedUser);
    return { success: true, data: updatedUser };
  }
};

// Listings Service
// Listings Service
export const listingsService = {
  async getListings(): Promise<ApiResponse<Listing[]>> {
    // 1. РЕАЛЬНЫЙ РЕЖИМ (Качаем из Supabase)
    if (!useAuthStore.getState().isDemoMode) {
      const { data, error } = await supabase.from('listings').select('*, owner:users(*)');
      if (error) return { success: false, error: error.message };
      
      // ВАЖНО: Закидываем скачанные данные в память сайта
      useListingsStore.getState().setListings(data || []);
      return { success: true, data: data || [] };
    }

    // 2. ДЕМО РЕЖИМ
    await delay(500);
    const { listings } = useListingsStore.getState();
    return { success: true, data: listings };
  },

  async getListingById(id: string): Promise<ApiResponse<Listing | null>> {
    if (!useAuthStore.getState().isDemoMode) {
      const { data, error } = await supabase.from('listings').select('*, owner:users(*)').eq('id', id).single();
      if (error) return { success: false, error: error.message };
      return { success: true, data: data };
    }

    await delay(300);
    const { listings } = useListingsStore.getState();
    const listing = listings.find((l) => l.id === id);
    return { success: true, data: listing || null };
  },

  async createListing(listingData: Partial<Listing>): Promise<ApiResponse<Listing>> {
    const authUser = useAuthStore.getState().user;
    if (!authUser) return { success: false, error: 'Not authenticated' };

    // 1. РЕАЛЬНЫЙ РЕЖИМ (Отправляем в Supabase)
    if (!useAuthStore.getState().isDemoMode) {
      const { data, error } = await supabase
        .from('listings')
        .insert({
          title: listingData.title,
          description: listingData.description,
          city: listingData.city,
          price: listingData.price,
          housingType: listingData.housingType, 
          capacity: listingData.capacity,
          tags: listingData.tags,
          images: listingData.images || [],
          availableSpots: listingData.availableSpots,
          owner_id: authUser.id // Привязываем пост к тебе
        })
        .select('*, owner:users(*)')
        .single();

      if (error) return { success: false, error: error.message };
      
      // Сразу показываем на экране
      useListingsStore.getState().addListing(data);
      return { success: true, data };
    }

    // 2. ДЕМО РЕЖИМ
    await delay(800);
    const newListing: Listing = {
      id: `listing-${Date.now()}`,
      title: listingData.title || '',
      description: listingData.description || '',
      city: listingData.city || 'Алматы',
      price: listingData.price || 0,
      housingType: listingData.housingType || 'room',
      capacity: listingData.capacity || 1,
      tags: listingData.tags || [],
      images: listingData.images || ['https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?w=800'],
      availableSpots: listingData.availableSpots || 1,
      owner: authUser,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    useListingsStore.getState().addListing(newListing);
    return { success: true, data: newListing };
  },

  async updateListing(id: string, listingData: Partial<Listing>): Promise<ApiResponse<Listing>> {
    return { success: false, error: 'Not implemented' };
  },

  async deleteListing(id: string): Promise<ApiResponse<void>> {
    return { success: false, error: 'Not implemented' };
  },
};

// Interests Service
export const interestsService = {
  async getInterests(): Promise<ApiResponse<Interest[]>> {
    await delay(300);
    const { interests } = useInterestsStore.getState();
    return { success: true, data: interests };
  },

  async getMyListingsInterests(): Promise<ApiResponse<Interest[]>> {
    await delay(300);
    
    const authUser = useAuthStore.getState().user;
    const { interests } = useInterestsStore.getState();
    
    if (!authUser) {
      return { success: true, data: [] };
    }

    const myListingsInterests = interests.filter(
      (interest) => interest.listing.owner.id === authUser.id
    );

    return { success: true, data: myListingsInterests };
  },

  async sendInterest(listing: Listing): Promise<ApiResponse<Interest>> {
    await delay(500);
    
    const authUser = useAuthStore.getState().user;
    if (!authUser) {
      return { success: false, error: 'Not authenticated' };
    }

    const newInterest: Interest = {
      id: `interest-${Date.now()}`,
      listing,
      interestedUser: authUser,
      status: 'pending',
      createdAt: new Date().toISOString(),
    };

    useInterestsStore.getState().addInterest(listing);

    return { success: true, data: newInterest };
  },

  async updateInterestStatus(
    interestId: string, 
    status: 'pending' | 'accepted' | 'rejected'
  ): Promise<ApiResponse<Interest>> {
    await delay(300);
    
    useInterestsStore.getState().updateInterestStatus(interestId, status);
    
    const { interests } = useInterestsStore.getState();
    const interest = interests.find((i) => i.id === interestId);
    
    return { success: true, data: interest! };
  },
};

// Search Service
export const searchService = {
  async searchListings(params: {
    city?: string;
    keyword?: string;
    housingType?: HousingType | '';
    priceMin?: number;
    priceMax?: number;
    capacity?: number;
    tags?: LifestyleTag[];
  }): Promise<ApiResponse<Listing[]>> {
    await delay(400);
    
    const { listings } = useListingsStore.getState();
    
    const filtered = listings.filter((listing) => {
      if (params.city && listing.city !== params.city) return false;
      if (params.keyword) {
        const keyword = params.keyword.toLowerCase();
        if (!listing.title.toLowerCase().includes(keyword) &&
            !listing.description.toLowerCase().includes(keyword)) {
          return false;
        }
      }
      if (params.housingType && listing.housingType !== params.housingType) return false;
      if (params.priceMin && listing.price < params.priceMin) return false;
      if (params.priceMax && listing.price > params.priceMax) return false;
      if (params.capacity && listing.capacity < params.capacity) return false;
      if (params.tags && params.tags.length > 0) {
        if (!params.tags.some((tag) => listing.tags.includes(tag))) return false;
      }
      return true;
    });

    return { success: true, data: filtered };
  },
};

// Comments Service
export const commentsService = {
  async getCommentsByListingId(listingId: string): Promise<ApiResponse<Comment[]>> {
    if (!useAuthStore.getState().isDemoMode) {
      const { data, error } = await supabase
        .from('comments')
        .select('*, user:users(*)')
        .eq('listing_id', listingId);
      if (error) return { success: false, error: error.message };
      return { success: true, data: data || [] };
    }

    await delay(300);
    const { comments } = useCommentsStore.getState();
    const listingComments = comments.filter((c) => c.listing_id === listingId);
    return { success: true, data: listingComments };
  },

  async addComment(listingId: string, content: string): Promise<ApiResponse<Comment>> {
    const authUser = useAuthStore.getState().user;
    if (!authUser) {
      return { success: false, error: 'Not authenticated' };
    }

    if (!useAuthStore.getState().isDemoMode) {
      const { data, error } = await supabase
        .from('comments')
        .insert({
          listing_id: listingId,
          user_id: authUser.id,
          content,
        })
        .select('*, user:users(*)')
        .single();

      if (error) return { success: false, error: error.message };
      return { success: true, data: data };
    }

    await delay(500);

    const newComment: Comment = {
      id: `comment-${Date.now()}`,
      listing_id: listingId,
      user_id: authUser.id,
      user: authUser,
      content,
      createdAt: new Date().toISOString(),
    };

    useCommentsStore.getState().addComment(newComment);

    return { success: true, data: newComment };
  },
};

// Messages Service
export const messagesService = {
  async getMessages(userId1: string, userId2: string): Promise<ApiResponse<Message[]>> {
    if (!useAuthStore.getState().isDemoMode) {
      const { data, error } = await supabase
        .from('messages')
        .select('*')
        .or(`and(sender_id.eq.${userId1},receiver_id.eq.${userId2}),and(sender_id.eq.${userId2},receiver_id.eq.${userId1})`)
        .order('createdAt', { ascending: true });
      if (error) return { success: false, error: error.message };
      return { success: true, data: data || [] };
    }

    await delay(300);
    const { messages } = useMessagesStore.getState();
    const chatMessages = messages.filter(
      (m) => (m.sender_id === userId1 && m.receiver_id === userId2) ||
             (m.sender_id === userId2 && m.receiver_id === userId1)
    ).sort((a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime());

    return { success: true, data: chatMessages };
  },

  async sendMessage(receiverId: string, content: string): Promise<ApiResponse<Message>> {
    const authUser = useAuthStore.getState().user;
    if (!authUser) {
      return { success: false, error: 'Not authenticated' };
    }

    if (!useAuthStore.getState().isDemoMode) {
      const { data, error } = await supabase
        .from('messages')
        .insert({
          sender_id: authUser.id,
          receiver_id: receiverId,
          content,
        })
        .select()
        .single();
      if (error) return { success: false, error: error.message };
      return { success: true, data: data };
    }

    await delay(300);

    const newMessage: Message = {
      id: `msg-${Date.now()}`,
      sender_id: authUser.id,
      receiver_id: receiverId,
      content,
      createdAt: new Date().toISOString(),
    };

    useMessagesStore.getState().addMessage(newMessage);

    return { success: true, data: newMessage };
  },
};
