import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import type { 
  User, 
  Listing, 
  Interest, 
  SearchFilters, 
  Comment, 
  Message 
} from '../types';

// --- Mock data for demo purposes ---
const mockListings: Listing[] = [
  {
    id: '1',
    title: 'Уютная комната в центре Алматы',
    description: 'Светлая и просторная комната в самом сердце города. Рядом метро, магазины и кафе. Идеально для студентов и молодых специалистов.',
    city: 'Алматы',
    price: 85000,
    housingType: 'room',
    capacity: 2,
    tags: ['student-friendly', 'quiet'],
    images: [
      'https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?w=800',
      'https://images.unsplash.com/photo-1502672260266-1c1ef2d93688?w=800',
    ],
    availableSpots: 1,
    owner: {
      id: 'u1',
      name: 'Айгуль К.',
      email: 'aigul@example.com',
      city: 'Алматы',
      avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150',
      bio: 'Владелец квартиры, сдаю уже 3 года. Люблю порядок и уют.',
      createdAt: '2024-01-15',
    },
    createdAt: '2024-03-01',
    updatedAt: '2024-03-01',
  },
  {
    id: '2',
    title: 'Современная квартира-студия в Астане',
    description: 'Новая квартира с евроремонтом в престижном районе. Панорамные окна, вся техника включена. Рядом ЭКСПО и Байтерек.',
    city: 'Астана',
    price: 150000,
    housingType: 'apartment',
    capacity: 2,
    tags: ['quiet', 'no-smoking'],
    images: [
      'https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?w=800',
      'https://images.unsplash.com/photo-1484154218962-a197022b5858?w=800',
    ],
    availableSpots: 1,
    owner: {
      id: 'u2',
      name: 'Нурлан Б.',
      email: 'nurlan@example.com',
      city: 'Астана',
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150',
      bio: 'Бизнесмен, сдаю квартиру в аренду. Ответственный арендодатель.',
      createdAt: '2024-02-01',
    },
    createdAt: '2024-03-05',
    updatedAt: '2024-03-05',
  }
];

const defaultFilters: SearchFilters = {
  city: '',
  keyword: '',
  housingType: '',
  priceMin: 0,
  priceMax: 1000000,
  capacity: 1,
  tags: [],
};

// --- Auth Store ---
interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  isDemoMode: boolean;
  login: (user: User) => void;
  logout: () => void;
  setLoading: (loading: boolean) => void;
  setDemoMode: (isDemoMode: boolean) => void;
}

export const useAuthStore = create<AuthState>()(
  persist(
    (set, get) => ({
      user: null,
      isAuthenticated: false,
      isLoading: false,
      isDemoMode: false,

      login: (user) => {
        set({ user, isAuthenticated: true, isLoading: false });
        
        // Если зашли в Демо, заполняем ленту моками
        if (get().isDemoMode) {
          useListingsStore.getState().setListings(mockListings);
        }
      },

      logout: () => {
        const isDemo = get().isDemoMode;
        set({ user: null, isAuthenticated: false, isLoading: false });
        
        // При выходе: если был LIVE — очищаем всё. Если DEMO — возвращаем моки.
        if (!isDemo) {
          useListingsStore.getState().setListings([]);
          useCommentsStore.getState().setComments([]);
          useMessagesStore.getState().setMessages([]);
        } else {
          useListingsStore.getState().setListings(mockListings);
        }
      },

      setLoading: (isLoading) => set({ isLoading }),
      setDemoMode: (isDemoMode) => set({ isDemoMode }),
    }),
    { name: 'dwello-auth' }
  )
);

// --- Listings Store ---
interface ListingsState {
  listings: Listing[];
  filteredListings: Listing[];
  isLoading: boolean;
  filters: SearchFilters;
  setListings: (listings: Listing[]) => void;
  addListing: (listing: Listing) => void;
  updateFilters: (filters: Partial<SearchFilters>) => void;
  resetFilters: () => void;
  filterListings: () => void;
  setLoading: (loading: boolean) => void;
}

export const useListingsStore = create<ListingsState>()((set, get) => ({
  listings: mockListings,
  filteredListings: mockListings,
  isLoading: false,
  filters: defaultFilters,

  setListings: (listings) => {
    set({ listings });
    get().filterListings();
  },

  addListing: (listing) => {
    set({ listings: [listing, ...get().listings] });
    get().filterListings();
  },

  updateFilters: (newFilters) => {
    set({ filters: { ...get().filters, ...newFilters } });
    get().filterListings();
  },

  resetFilters: () => {
    set({ filters: defaultFilters });
    get().filterListings();
  },

  filterListings: () => {
    const { listings, filters } = get();
    const filtered = listings.filter((listing) => {
      if (filters.city && listing.city !== filters.city) return false;
      if (filters.keyword) {
        const keyword = filters.keyword.toLowerCase();
        const matches = listing.title.toLowerCase().includes(keyword) || 
                        listing.description.toLowerCase().includes(keyword);
        if (!matches) return false;
      }
      if (filters.housingType && listing.housingType !== filters.housingType) return false;
      if (listing.price < filters.priceMin || listing.price > filters.priceMax) return false;
      if (listing.capacity < filters.capacity) return false;
      if (filters.tags.length > 0) {
        if (!filters.tags.every(tag => listing.tags.includes(tag))) return false;
      }
      return true;
    });
    set({ filteredListings: filtered });
  },

  setLoading: (isLoading) => set({ isLoading }),
}));

// --- Interests Store ---
interface InterestsState {
  interests: Interest[];
  setInterests: (interests: Interest[]) => void;
  addInterest: (listing: Listing) => void;
  updateInterestStatus: (id: string, status: 'pending' | 'accepted' | 'rejected') => void;
}

export const useInterestsStore = create<InterestsState>()((set, get) => ({
  interests: [],
  setInterests: (interests) => set({ interests }),
  addInterest: (listing) => {
    const user = useAuthStore.getState().user;
    if (!user) return;
    const newInterest: Interest = {
      id: `int-${Date.now()}`,
      listing,
      interestedUser: user,
      status: 'pending',
      createdAt: new Date().toISOString(),
    };
    set({ interests: [...get().interests, newInterest] });
  },
  updateInterestStatus: (id, status) => {
    set({
      interests: get().interests.map(i => i.id === id ? { ...i, status } : i)
    });
  },
}));

// --- UI / Language / Settings ---
interface UIState {
  isFilterPanelOpen: boolean;
  toggleFilterPanel: () => void;
  closeFilterPanel: () => void;
}
export const useUIStore = create<UIState>()((set) => ({
  isFilterPanelOpen: false,
  toggleFilterPanel: () => set(s => ({ isFilterPanelOpen: !s.isFilterPanelOpen })),
  closeFilterPanel: () => set({ isFilterPanelOpen: false }),
}));

export type Language = 'ru' | 'kk';
interface LanguageState {
  language: Language;
  setLanguage: (lang: Language) => void;
}
export const useLanguageStore = create<LanguageState>()(
  persist((set) => ({
    language: 'ru',
    setLanguage: (language) => set({ language }),
  }), { name: 'dwello-language' })
);

interface SettingsState {
  notifications: boolean;
  toggleNotifications: () => void;
}
export const useSettingsStore = create<SettingsState>()(
  persist((set) => ({
    notifications: true,
    toggleNotifications: () => set(s => ({ notifications: !s.notifications })),
  }), { name: 'dwello-settings' })
);

// --- Comments & Messages ---
interface CommentsState {
  comments: Comment[];
  addComment: (c: Comment) => void;
  setComments: (c: Comment[]) => void;
}
export const useCommentsStore = create<CommentsState>()((set, get) => ({
  comments: [],
  addComment: (comment) => set({ comments: [...get().comments, comment] }),
  setComments: (comments) => set({ comments }),
}));

interface MessagesState {
  messages: Message[];
  addMessage: (m: Message) => void;
  setMessages: (m: Message[]) => void;
}
export const useMessagesStore = create<MessagesState>()((set, get) => ({
  messages: [],
  addMessage: (message) => set({ messages: [...get().messages, message] }),
  setMessages: (messages) => set({ messages }),
}));